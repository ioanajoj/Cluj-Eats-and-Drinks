package com.example.firebasestuff;

import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mingle.sweetpick.CustomDelegate;
import com.mingle.sweetpick.SweetSheet;

import java.util.ArrayList;

public class WelcomeActivity extends AppCompatActivity {

    // Firebase
    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();
    DatabaseReference locationRef = mRootRef.child("locations");
    DatabaseReference openHoursRef = mRootRef.child("openHours");
    DatabaseReference hoursRef = mRootRef.child("hours");
    DatabaseReference locationOpenHoursRef;

    // widgets
    private RecyclerView mRecyclerView;
    private TextView welcomeField;
    private EditText typeOfFoodEditText;
    private EditText dayEditText;
    private EditText hourEditText;
    private TextView openHoursTextView;
    private Button logOutButton;
    private Button filterButton;

    // vars
    private ArrayList<Location> locations = new ArrayList<>();
    private LocationsRecyclerViewAdapter locationsRecyclerViewAdapter;
    private ArrayList<String> hourKeys = new ArrayList<>();
    private ArrayList<String> locationsIDs = new ArrayList<>();
    private ArrayList<Location> finalLocations = new ArrayList<>();

    // SweetSheet
    private SweetSheet mSweetSheet;
    private RelativeLayout locationRelativeLayout;
        // Open Hours data
    ArrayList<String> openHoursIDs = new ArrayList<>();
    ArrayList<OpenDayTime> openDayTimes = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_activity);
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        mRecyclerView = findViewById(R.id.locationsRecyclerView);
        initRecyclerView();

        locationRelativeLayout = findViewById(R.id.welcome_rlayout);

        logOutButton = findViewById(R.id.logOutButton);
        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                finish();
            }
        });

        filterButton = findViewById(R.id.filterButton);
        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFilterDialog();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        String email = mAuth.getCurrentUser().getEmail();
        welcomeField = findViewById(R.id.welcomeText);
        welcomeField.setText("Welcome back, " + email);

        locationRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                finalLocations.clear();
                for(DataSnapshot snap : dataSnapshot.getChildren()) {
                    Location location = snap.getValue(Location.class);
                    System.out.println(location);
                    locations.add(location);
                    finalLocations.add(location);
                }
                locationsRecyclerViewAdapter.notifyDataSetChanged();
                startFilterDialog();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("WelcomeActivity", "Failed to read value.", error.toException());
            }
        });
    }

    private void initRecyclerView() {
        if(locationsRecyclerViewAdapter == null){
            locationsRecyclerViewAdapter = new LocationsRecyclerViewAdapter(this, finalLocations);
        }
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(locationsRecyclerViewAdapter);

        locationsRecyclerViewAdapter.setOnItemClickListener(new LocationsRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemCLick(int position) {
                Toast.makeText(getApplicationContext(), finalLocations.get(position).toString(), Toast.LENGTH_SHORT).show();

                // Slider method
                Location selectedLocation = finalLocations.get(position);
                initCustomView(selectedLocation);
                mSweetSheet.toggle();

                // New Fragment method
//                LocationDetailsFragment fragment = new LocationDetailsFragment();
//                fragment.setLocation(finalLocations.get(position));
//                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
//                ft.replace(R.id.fragment_container, fragment);
//                ft.commit();

            }
        });
    }

    private void startFilterDialog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.filter_options, null);
        builder1.setView(dialogView)
                .setMessage("Let's filter a bit.")
                .setCancelable(true)
                .setPositiveButton(
                        "Do your magic",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                typeOfFoodEditText = dialogView.findViewById(R.id.typeOfFoodEditText);
                                dayEditText = dialogView.findViewById(R.id.dayEditText);
                                hourEditText = dialogView.findViewById(R.id.hourEditText);
                                String foodType = typeOfFoodEditText.getText().toString();
                                String day = dayEditText.getText().toString();
                                String hour = hourEditText.getText().toString();
                                Choice choice = new Choice(foodType, day, hour);
                                finalLocations.clear();
                                getNewLocations(choice);
                                locationsRecyclerViewAdapter.notifyDataSetChanged();
                                dialog.cancel();
                            }
                        })
                .setNegativeButton(
                        "Leave me alone",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void initCustomView(Location mLocation) {
        mSweetSheet = new SweetSheet(locationRelativeLayout);
        CustomDelegate customDelegate = new CustomDelegate(true,
                CustomDelegate.AnimationType.DuangLayoutAnimation);
        View customView = LayoutInflater.from(this).inflate(R.layout.location_details_fragment, null, false);

        // Set fields
        TextView locationNameTextView = customView.findViewById(R.id.locationNameTextView);
        openHoursTextView = customView.findViewById(R.id.openHourContentTextView);
        ImageView locationImageView = customView.findViewById(R.id.locationImageView);
        TextView locationAddressTextView = customView.findViewById(R.id.addressTextView);

        locationNameTextView.setText(mLocation.getName());
        locationAddressTextView.setText(mLocation.getAddress());
        RequestOptions requestOptions = new RequestOptions()
                .placeholder(R.drawable.ic_launcher_background);
        Glide.with(this)
                .load(mLocation.getPhoto())
                .apply(requestOptions)
                .into(locationImageView);

        locationRef.orderByChild("name")
                .equalTo(mLocation.getName())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String locationKey = "";
                        for(DataSnapshot data : dataSnapshot.getChildren()) {
                            locationKey = data.getKey();
                        }
                        locationOpenHoursRef = openHoursRef.child(locationKey);
                        getOpenHoursIDs();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

        customDelegate.setCustomView(customView);
        mSweetSheet.setDelegate(customDelegate);
    }

    private void getNewLocations(Choice choice) {
        getLocationsByHour(choice);
    }

    private void getLocationsByHour(final Choice choice) {

        hoursRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                hourKeys.clear();
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    OpenDayTime odt = data.getValue(OpenDayTime.class);
                    if (odt.isOpen(choice.getDay(), choice.getHour()))
                        hourKeys.add(data.getKey());
                }
                openHoursRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        locationsIDs.clear();
                        for(DataSnapshot data : dataSnapshot.getChildren()) {
                            for(DataSnapshot data2 : data.getChildren()) {
                                if(hourKeys.contains(data2.getKey()))
                                    locationsIDs.add(data.getKey());
                            }
                        }
                        locationRef.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                finalLocations.clear();
                                for(DataSnapshot data : dataSnapshot.getChildren())
                                    if(locationsIDs.contains(data.getKey()))
                                        finalLocations.add(data.getValue(Location.class));
                                locationsRecyclerViewAdapter.notifyDataSetChanged();

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getOpenHoursIDs() {
        locationOpenHoursRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                openHoursIDs.clear();
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    String id = data.getKey();
                    openHoursIDs.add(id);
                }
                getOpenHours();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getOpenHours() {
        hoursRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                openDayTimes.clear();
                for(DataSnapshot data : dataSnapshot.getChildren()) {
                    if (openHoursIDs.contains(data.getKey())) {
                        OpenDayTime odt = data.getValue(OpenDayTime.class);
                        openDayTimes.add(odt);
                    }
                }
                openHoursTextView.setText(openDayTimes.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
